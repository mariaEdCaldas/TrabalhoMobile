package com.example.gerenciadordetarefas.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.gerenciadordetarefas.R;
import com.example.gerenciadordetarefas.database.localDatabase;
import com.example.gerenciadordetarefas.databinding.ActivityMainBinding;
import com.example.gerenciadordetarefas.entities.Usuario;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private localDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.btnRegister);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeUsuario = usernameEditText.getText().toString();
                String senhaUsuario = passwordEditText.getText().toString();
                db = localDatabase.getDatabase(getApplicationContext());
                Usuario usuario = db.UsuarioModel().autentica(nomeUsuario, senhaUsuario);
                if (usuario != null) {
                    int idUsuario = usuario.getId();
                    Intent UsuarioIntent = new Intent(MainActivity.this, PerfilUsuarioView.class);
                    UsuarioIntent.putExtra("ID_USUARIO",idUsuario);
                    startActivity(UsuarioIntent);
                    //Usuário regular autenticado com sucesso
                    Toast.makeText(MainActivity.this, "Logado com êxito, bem-vindo", Toast.LENGTH_SHORT).show();
                } else {
                    // Credenciais inválidas
                    Toast.makeText(MainActivity.this, "Usuario não existe, por favor se cadastre", Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerActivityIntent = new Intent(MainActivity.this, RegistroView.class);
                startActivity(registerActivityIntent);
            }
        });
    }
}