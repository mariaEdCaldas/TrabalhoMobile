package com.example.gerenciadordetarefas.views;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.gerenciadordetarefas.database.localDatabase;
import com.example.gerenciadordetarefas.databinding.ActivityPerfilUsuarioBinding;
import com.example.gerenciadordetarefas.entities.Usuario;

public class PerfilUsuarioView extends AppCompatActivity {
    private ActivityPerfilUsuarioBinding binding;
    private localDatabase db;
    private int userId;
    private Button buttonListaTarefas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPerfilUsuarioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = localDatabase.getDatabase(this);

        userId = getIntent().getIntExtra("ID_USUARIO",-1);

        if (userId != -1) {
            Usuario usuario = db.UsuarioModel().getUserById(userId);
            if (usuario != null) {
                binding.usernameEditTextEdit.setText(usuario.getUsername());
                binding.emailEditTextEdit.setText(usuario.getEmail());
                binding.usernameEditTextEdit.setEnabled(false);
                binding.emailEditTextEdit.setEnabled(false);
            }
            else {
                Toast.makeText(this, "Usuário não encontrado", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "ID de usuário inválido", Toast.LENGTH_SHORT).show();
        }
        buttonListaTarefas = binding.buttonListaTarefas;
        buttonListaTarefas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PerfilUsuarioView.this, ListaTarefasView.class);
                intent.putExtra("ID_USUARIO",userId);
                startActivity(intent);
            }
        });
    }
}
