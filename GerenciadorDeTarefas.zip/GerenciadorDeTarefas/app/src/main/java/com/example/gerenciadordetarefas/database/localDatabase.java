package com.example.gerenciadordetarefas.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.gerenciadordetarefas.dao.TarefaDAO;
import com.example.gerenciadordetarefas.dao.UsuarioDAO;
import com.example.gerenciadordetarefas.entities.Tarefas;
import com.example.gerenciadordetarefas.entities.Usuario;

import java.util.List;

@Database(entities = {Usuario.class, Tarefas.class}, version = 3)
public abstract class localDatabase extends RoomDatabase {
    private static localDatabase INSTANCE;
    public static localDatabase getDatabase(Context context) {
        if(INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                    localDatabase.class, "DbTeste").fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }
        return INSTANCE;
    }


    public abstract UsuarioDAO UsuarioModel();
    public abstract TarefaDAO tarefaModel();
    /*public List<Tarefas> getTarefasByUserId(int userId) {
        return tarefaModel().getTarefasByUserId(userId);
    }*/

}
