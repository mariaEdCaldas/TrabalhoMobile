package com.example.gerenciadordetarefas.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Tarefas {
    @PrimaryKey(autoGenerate = true)
    public int tarefaId;
    public int usuarioId;
    private String nome;
    private String prazo;
    private String prioridade;
    private String status;
    private boolean completa;


    public Tarefas(String nome, String prazo, String prioridade,String status) {
        this.nome = nome;
        this.prazo = prazo;
        this.prioridade = prioridade;
        this.status = status;
        this.completa = false; // Por padrão, a tarefa não está concluída;
    }

    // Getters e setters

    @Override
    public String toString() {
        return "Nome: " + nome + "\n" +
                "Prazo: " + prazo + "\n" +
                "Status: " + status + "\n" +
                "Prioridade: " + prioridade;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTarefaId() {
        return tarefaId;
    }
    public void setTarefaId(int tarefaId){
        this.tarefaId = tarefaId;
    }

    public String getPrazo() {
        return prazo;
    }



    public void setPrazo(String prazo) {
        this.prazo = prazo;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(String prioridade) {
        this.prioridade = prioridade;
    }

    public void setStatus (String status) {this.status = status;}

    public String getStatus(){ return status;}

    public boolean getCompleta() {
        return completa;
    }

    public void setCompleta(boolean completa) {
        this.completa = completa;
    }
}
