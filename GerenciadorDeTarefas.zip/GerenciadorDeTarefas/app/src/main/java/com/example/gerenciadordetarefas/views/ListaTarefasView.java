package com.example.gerenciadordetarefas.views;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.gerenciadordetarefas.R;
import com.example.gerenciadordetarefas.database.localDatabase;
import com.example.gerenciadordetarefas.databinding.ActivityHomePageBinding;
import com.example.gerenciadordetarefas.entities.Tarefas;

import java.util.ArrayList;
import java.util.List;

public class ListaTarefasView extends AppCompatActivity {
    private ListView listViewTarefas;
    private ArrayAdapter<Tarefas> tarefasAdapter;
    private localDatabase db;
    private List<Tarefas> ListTarefas;
    private Intent edtIntent;

    private int usuarioID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        com.example.gerenciadordetarefas.databinding.ActivityHomePageBinding binding = ActivityHomePageBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        db = localDatabase.getDatabase(getApplicationContext());
        listViewTarefas = binding.listViewTarefas;

        usuarioID = getIntent().getIntExtra("ID_USUARIO", -1);

        ListTarefas = new ArrayList<>();
        tarefasAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListTarefas);
        listViewTarefas.setAdapter(tarefasAdapter);
        binding.buttonAddTarefa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ListaTarefasView.this,TarefaView.class));
            }
        });
    }
    @Override
    protected void onResume(){
        super.onResume();
        edtIntent = new Intent(this, TarefaView.class);
        preencheTarefas();
    }
    private void preencheTarefas(){
        ListTarefas = db.tarefaModel().getAllTarefas();
        ArrayAdapter<Tarefas> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, ListTarefas);
        listViewTarefas.setAdapter(adapter);

        listViewTarefas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Tarefas tarefaSelecionada = ListTarefas.get(i);
                edtIntent.putExtra("TAREFA_SELECIONADA_ID",tarefaSelecionada.getTarefaId());
                startActivity(edtIntent);
            }
        });
        listViewTarefas.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Tarefas tarefaSelecionada = ListTarefas.get(position);


                new AlertDialog.Builder(ListaTarefasView.this)
                        .setTitle("Exclusão de tarefa")
                        .setMessage("Deseja excluir essa tarefa?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                excluir(tarefaSelecionada);
                            }
                        })
                        .setNegativeButton("Não", null)
                        .show();
                return true;
            }
        });
    }
    public void excluir(Tarefas tarefa) {
        db.tarefaModel().removeTarefa(tarefa);
        Toast.makeText(this, "Tarefa excluída com sucesso.", Toast.LENGTH_SHORT).show();
        finish();
    }
}
