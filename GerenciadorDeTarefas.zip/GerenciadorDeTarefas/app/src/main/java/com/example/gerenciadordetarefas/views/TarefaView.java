package com.example.gerenciadordetarefas.views;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.gerenciadordetarefas.database.localDatabase;
import com.example.gerenciadordetarefas.databinding.ActivityTarefasViewBinding;
import com.example.gerenciadordetarefas.entities.Tarefas;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TarefaView extends AppCompatActivity {
    private localDatabase db;
    private ActivityTarefasViewBinding binding;
    private Tarefas dbTarefas;
    private int dbTarefaId;
    private String[] items;
    private Spinner spnPrioridades;
    private ArrayAdapter prioridadesAdapter;

    private TextView textViewDataSelecionada;
    private Button buttonSelecionaData;
    private Calendar DataSelecionada;

    private String status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTarefasViewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = localDatabase.getDatabase(getApplicationContext());
        CheckBox checkboxTarefaCompleta = binding.taskCompletedCheckBox;
        status = "Pendente";
        spnPrioridades = binding.editTextTarefaPrioridade;
        dbTarefaId = getIntent().getIntExtra("TAREFA_SELECIONADA_ID",-1);
        textViewDataSelecionada = binding.textViewDataSelecionada;
        buttonSelecionaData = binding.buttonSelecionaData;
        CheckBox checkbox = binding.taskCompletedCheckBox;
        CheckBox checkbox2 = binding.taskCompletedCheckBox2;

        if (dbTarefaId != -1) {
            preencheTarefa();
        }

        buttonSelecionaData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    status = "Feito";
                }
            }
        });
        checkbox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b){
                    status = "Pendente";
                }
            }
        });
        binding.buttonSaveTarefa.setOnClickListener(v->saveTarefa());
        binding.buttonDeleteTarefa.setOnClickListener(v->deleteTarefa());
    }
    public void showDatePicker() {
        final Calendar currentDate = Calendar.getInstance();
        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                DataSelecionada = Calendar.getInstance();
                DataSelecionada.set(Calendar.YEAR, year);
                DataSelecionada.set(Calendar.MONTH, monthOfYear);
                DataSelecionada.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                String formattedDate = sdf.format(DataSelecionada.getTime());
                textViewDataSelecionada.setText(formattedDate);
            }
        }, year, month, day);

        datePickerDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(dbTarefaId>=0){
            preencheTarefa();
        }
        preenchePrioridades();
    }
    private void preencheTarefa() {
        dbTarefas = db.tarefaModel().getTarefa(dbTarefaId);
        binding.editTextTarefaNome.setText(dbTarefas.getNome());
        binding.textViewDataSelecionada.setText(dbTarefas.getPrazo());
        binding.taskCompletedCheckBox.setChecked(dbTarefas.getCompleta());
        if (dbTarefas != null) {
            binding.editTextTarefaNome.setText(dbTarefas.getNome());
            binding.textViewDataSelecionada.setText(dbTarefas.getPrazo());

            // Verifica e seta o status da tarefa nos checkboxes
            if (dbTarefas.getStatus().equals("Feito")) {
                binding.taskCompletedCheckBox.setChecked(true);
            } else if (dbTarefas.getStatus().equals("Pendente")) {
                binding.taskCompletedCheckBox2.setChecked(true);
            }

            preenchePrioridades(dbTarefas.getPrioridade());
        }
    }
    private void preenchePrioridades(){
        items = new String[]{"Urgente", "Moderada", "Baixa"};
        prioridadesAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);
        spnPrioridades.setAdapter(prioridadesAdapter);
    }
    private void preenchePrioridades(String prioridadeTarefaExistente) {
        String[] items = {"Urgente", "Moderada", "Baixa"};
        ArrayAdapter<String> prioridadesAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items);
        binding.editTextTarefaPrioridade.setAdapter(prioridadesAdapter);

        // Encontra a posição da prioridade da tarefa existente na lista de prioridades
        int posicaoPrioridade = -1;
        for (int i = 0; i < items.length; i++) {
            if (items[i].equals(prioridadeTarefaExistente)) {
                posicaoPrioridade = i;
                break;
            }
        }

        // Seleciona a prioridade da tarefa existente no Spinner
        if (posicaoPrioridade >= 0) {
            binding.editTextTarefaPrioridade.setSelection(posicaoPrioridade);
        }
    }
    private void saveTarefa() {
        String tarefaNome = binding.editTextTarefaNome.getText().toString();
        String tarefaPrazo = binding.textViewDataSelecionada.getText().toString();
        String prioridade = "";

        if (!binding.taskCompletedCheckBox.isChecked() && !binding.taskCompletedCheckBox2.isChecked()) {
            status = "Pendente";
        }

        if(spnPrioridades.getSelectedItem() != null){
            prioridade = spnPrioridades.getSelectedItem().toString();
        }

        if (tarefaNome.isEmpty()) {
            Toast.makeText(this, "Digite um nome para a tarefa", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbTarefas != null) {
            // Atualiza os dados da tarefa existente
            dbTarefas.setNome(tarefaNome);
            dbTarefas.setPrazo(tarefaPrazo);
            dbTarefas.setPrioridade(prioridade);
            dbTarefas.setStatus(status);

            db.tarefaModel().updateTarefa(dbTarefas);
            Toast.makeText(this, "Tarefa atualizada com sucesso", Toast.LENGTH_SHORT).show();
        } else {
            // Cria uma nova tarefa
            Tarefas novaTarefa = new Tarefas(tarefaNome, tarefaPrazo, prioridade, status);
            db.tarefaModel().addTarefa(novaTarefa);
            Toast.makeText(this, "Tarefa cadastrada com sucesso", Toast.LENGTH_SHORT).show();
        }

        finish();

    }

    private void deleteTarefa() {
        new AlertDialog.Builder(this)
                .setTitle("Exclusão de tarefa")
                .setMessage("Deseja excluir essa tarefa?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        excluir();
                    }
                })
                .setNegativeButton("Não", null)
                .show();
    }
    public void excluir() {
        db.tarefaModel().removeTarefa(dbTarefas);
        Toast.makeText(this, "Tarefa excluída com sucesso.", Toast.LENGTH_SHORT).show();
        finish();
    }
    public void voltar(View view) {
        finish();
    }
}


