package com.example.gerenciadordetarefas.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.gerenciadordetarefas.entities.Tarefas;

import java.util.List;

@Dao
public interface TarefaDAO {
    @Query("SELECT * FROM Tarefas WHERE tarefaId = :id LIMIT 1")
    Tarefas getTarefa(int id);

    @Query("SELECT * FROM Tarefas WHERE usuarioId = :userId")
    List<Tarefas> getTarefasByUserId(int userId);
    @Query("SELECT * FROM Tarefas WHERE prioridade = :prioridade")
    List<Tarefas> getTarefasByPrioridade(String prioridade);

    @Insert
    void addTarefa(Tarefas... tarefa);

    @Delete
    void removeTarefa(Tarefas tarefa);

    @Update
    void updateTarefa(Tarefas tarefa);

    @Query("SELECT * FROM Tarefas")
    List<Tarefas> getAllTarefas();
}
