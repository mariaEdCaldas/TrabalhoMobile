package com.example.gerenciadordetarefas.dao;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.gerenciadordetarefas.entities.Usuario;

@Dao
public interface UsuarioDAO {
    @Insert
    void insertUsuario(Usuario usuario);

    @Query("SELECT * FROM usuarios WHERE username = :username AND password = :password")
    Usuario autentica(String username, String password);

    @Query("SELECT * FROM usuarios WHERE id = :idUsuario")
    Usuario getUserById(int idUsuario);
}
