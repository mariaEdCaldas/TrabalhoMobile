package com.example.gerenciadordetarefas.views;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.gerenciadordetarefas.R;
import com.example.gerenciadordetarefas.database.localDatabase;
import com.example.gerenciadordetarefas.databinding.ActivityRegistroUsuarioBinding;
import com.example.gerenciadordetarefas.entities.Usuario;

public class RegistroView extends AppCompatActivity {
    private EditText usernameEditTextRegister;
    private EditText passwordEditTextRegister;
    private EditText emailEditTextRegister;
    private Button cadButton;
    private ActivityRegistroUsuarioBinding binding;
    private localDatabase db;
    private Usuario dbUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        binding = ActivityRegistroUsuarioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        db = localDatabase.getDatabase(getApplicationContext());

        usernameEditTextRegister = findViewById(R.id.usernameEditTextRegister);
        emailEditTextRegister = findViewById(R.id.emailEditTextRegister);
        passwordEditTextRegister = findViewById(R.id.passwordEditTextRegister);
        cadButton = findViewById(R.id.cadButton);

        cadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastraUsuario();
            }
        });
    }
    public void cadastraUsuario(){
        String nameRegister = binding.usernameEditTextRegister.getText().toString();
        String emailRegister = binding.emailEditTextRegister.getText().toString();
        String passwordRegister = binding.passwordEditTextRegister.getText().toString();

        if(nameRegister.equals("")){
            Toast.makeText(this, "Insira um nome válido", Toast.LENGTH_SHORT).show();
            return;
        }

        if(emailRegister.equals("")){
            Toast.makeText(this, "Insira um email válido", Toast.LENGTH_SHORT).show();
            return;
        }

        if(passwordRegister.equals("")){
            Toast.makeText(this, "Insira uma senha válida", Toast.LENGTH_SHORT).show();
            return;
        }

        Usuario novoUsuario = new Usuario();
        novoUsuario.setUsername(nameRegister);
        novoUsuario.setPassword(passwordRegister);
        novoUsuario.setEmail(emailRegister);

        db.UsuarioModel().insertUsuario(novoUsuario);
        Toast.makeText(this, "Cadastro feito com sucesso, efetue o Login", Toast.LENGTH_SHORT).show();
        finish();

    }
    public void voltar(View view){
        finish();
    }
}
